//
// Created by resolution on 31.03.17.
//

#ifndef GENERAL3_DEFINES_H
#define GENERAL3_DEFINES_H

#define MAX_CAP 500000
<<<<<<< Updated upstream
#define MAX_SIZE 500000
=======
int quantity=0;
>>>>>>> Stashed changes


#endif //GENERAL3_DEFINES_H
